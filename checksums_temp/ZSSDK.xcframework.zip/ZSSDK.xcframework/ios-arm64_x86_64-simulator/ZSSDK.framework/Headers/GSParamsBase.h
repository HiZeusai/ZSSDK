//
//  ParamsBase.h
//  GSSDK
//
//  Created by sen on 2021/12/14.
//

#import <Foundation/Foundation.h>

@interface GSParamsBase : NSObject

@property (nonatomic, copy) NSDictionary *extend;

@end
