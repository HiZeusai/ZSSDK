//
//  YKIAPStoreKit.h
//  YKIAPStoreKit
//
//  Created by qingyun on 2024/6/20.
//

#import <Foundation/Foundation.h>

//! Project version number for YKIAPStoreKit.
FOUNDATION_EXPORT double YKIAPStoreKitVersionNumber;

//! Project version string for YKIAPStoreKit.
FOUNDATION_EXPORT const unsigned char YKIAPStoreKitVersionString[];

#define YKIAPStoreKitVersion @"1.0.0"

// In this header, you should import all the public headers of your framework using statements like #import <YKIAPStoreKit/PublicHeader.h>
#import <YKIAPStoreKit/YKIAPResult.h>
#import <YKIAPStoreKit/YKPurchaseIAP.h>
#import <YKIAPStoreKit/YKTransaction.h>
#import <YKIAPStoreKit/YKIAPProdut.h>
