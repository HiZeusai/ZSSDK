//
//  GSColorConstants.h
//  GSMemberCenter
//
//  Created by yoka on 2023/3/16.
//

/// 请勿使用，后期会移除

#ifndef GSColorConstants_h
#define GSColorConstants_h
static NSString * const color_white_1 = @"ffffff";

static NSString * const color_black_1 = @"333333";
static NSString * const color_black_2 = @"151515";
static NSString * const color_black_3 = @"272e3b";
static NSString * const color_black_4 = @"2c1a1e";
static NSString * const color_black_5 = @"201f1c";

static NSString * const color_gray_1 = @"808080";
static NSString * const color_gray_2 = @"000000";
static NSString * const color_gray_3 = @"f2f4ff";
static NSString * const color_gray_4 = @"f4f6fc";
static NSString * const color_gray_5 = @"415374";
static NSString * const color_gray_6 = @"cfcfcf";
static NSString * const color_gray_7 = @"1a325d";
static NSString * const color_gray_8 = @"1d2837";
static NSString * const color_gray_9 = @"e7f0ff";


static NSString * const color_red_1 = @"df4d4d";
static NSString * const color_red_2 = @"d85a5a";



static NSString * const color_blue_1 = @"4461a8";
static NSString * const color_blue_2 = @"dfe1f3";
static NSString * const color_blue_3 = @"00291a";
static NSString * const color_blue_4 = @"ebf3ff";
static NSString * const color_blue_5 = @"515880";
static NSString * const color_blue_6 = @"191b46";
static NSString * const color_blue_7 = @"5a78d8";



static NSString * const color_green_1 = @"46be3c";
static NSString * const color_green_2 = @"2b6952";
static NSString * const color_green_3 = @"001b10";
static NSString * const color_green_4 = @"c5ffdd";


static NSString * const color_orange_1 = @"7a5918";
static NSString * const color_orange_2 = @"ffe4af";
static NSString * const color_orange_3 = @"ddb976";
static NSString * const color_orange_4 = @"ceac77";
static NSString * const color_orange_5 = @"f3cf77";


static NSString * const color_brown_1 = @"422e0d";
static NSString * const color_brown_2 = @"A0500F";


static NSString * const color_purple_1 = @"5a4688";
static NSString * const color_purple_2 = @"f5ebff";




#endif /* GSColorConstants_h */
