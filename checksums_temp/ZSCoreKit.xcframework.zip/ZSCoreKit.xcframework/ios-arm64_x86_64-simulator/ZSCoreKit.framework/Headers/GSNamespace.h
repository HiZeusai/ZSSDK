//
//  GSNamespace.h
//
//  Created by guanshuailuo on 2021/11/30.
//

#ifndef GSNamespace_h
#define GSNamespace_h

#define MASCompositeConstraint GSMASCompositeConstraint
#define MASConstraint GSMASConstraint
#define MASConstraintMaker GSMASConstraintMaker
#define MASLayoutConstraint GSMASLayoutConstraint
#define Masonry GSMasonry
#define MASUtilities GSMASUtilities
#define MASViewAttribute GSMASViewAttribute
#define MASViewConstraint GSMASViewConstraint


#define MASAdditions GSMASAdditions
#define MASShorthandAdditions GSMASShorthandAdditions
#define MASDebugAdditions GSMASDebugAdditions

#define modelWithJSON GS_modelWithJSON
#define modelWithDictionary GS_modelWithDictionary
#define modelSetWithJSON GS_modelSetWithJSON
#define modelSetWithDictionary GS_modelSetWithDictionary
#define modelToJSONObject GS_modelToJSONObject
#define modelToJSONData GS_modelToJSONData
#define modelToJSONString GS_modelToJSONString
#define modelCopy GS_modelCopy
#define modelEncodeWithCoder GS_modelEncodeWithCoder
#define modelInitWithCoder GS_modelInitWithCoder
#define modelHash GS_modelHash
#define modelIsEqual GS_modelIsEqual
#define modelDescription GS_modelDescription
#define YYClassInfo   GSYYClassInfo
#define YYModel     GSYYModel
#define YYClassIvarInfo     GSYYClassIvarInfo
#define YYClassMethodInfo     GSYYClassMethodInfo
#define YYClassPropertyInfo     GSYYClassPropertyInfo
#define YYEncodingType     GSYYEncodingType
#define YYEncodingGetType     GSYYEncodingGetType
#define _YYModelPropertyMeta   _GSYYModelPropertyMeta
#define _YYModelMeta           _GSYYModelMeta








#endif /* GSNamespace_h */
