//
//  GSAppHook.h
//  GSAppProxyDemo
//
//  Created by 帅乐 on 2022/5/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GSAppHook : NSObject

@end

NS_ASSUME_NONNULL_END
