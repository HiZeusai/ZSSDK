//
//  GSViewUtils.h
//  GSCoreKit
//
//  Created by yoka on 2023/2/6.
//

#import <UIKit/UIKit.h>



@interface GSViewUtils : UIView
//+(UIView *)getTopView;
//+(UIViewController *)getRootViewController;
//+(UIView *)getkeyWindow;


@end


