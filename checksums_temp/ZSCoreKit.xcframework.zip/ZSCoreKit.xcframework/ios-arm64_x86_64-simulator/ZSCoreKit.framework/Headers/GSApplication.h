//
//  GSApplication.h
//  GSSDK
//
//  Created by YOKA on 2022/12/30.
//

#import <Foundation/Foundation.h>

@class UIWindow, UIViewController, UIView;

NS_ASSUME_NONNULL_BEGIN

@interface GSApplication : NSObject

//@property (nonatomic, strong, class, readonly) UIWindow *keyWindow;
//@property (nonatomic, strong, class, readonly) UIViewController *rootViewController;
//@property (nonatomic, strong, class, readonly) UIView *rootView;
//@property (nonatomic, strong, class, readonly) UIViewController *topViewController;
//@property (nonatomic, strong, class, readonly) UIView *topView;
//
//+ (BOOL)canOpenURLString:(NSString *)str;

@end

NS_ASSUME_NONNULL_END
